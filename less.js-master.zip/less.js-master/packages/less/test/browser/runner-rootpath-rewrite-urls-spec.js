describe('less.js browser test - rootpath and rewrite urls', function() {
    testLessEqualsInDocument();
});
